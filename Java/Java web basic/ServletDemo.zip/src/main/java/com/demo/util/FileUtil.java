package com.demo.util;

/**
 * @Description: TODO
 * @author: 01369674
 * @date: 2018/5/28
 */
public class FileUtil {
    public static void upload(String path){

    }

}
